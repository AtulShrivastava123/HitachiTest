package testScripts;

import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import Base.TestBase;
import pages.Search;

public class OpenReturnedResult {
	
	Search srchObj = new Search();
	TestBase testBaseObj = new TestBase();
	String searchKeyword = "Technology";
	String applicationURL = "https://global.hitachi-solutions.com";
	
	
	@BeforeMethod
	public void startTest()
	{
		testBaseObj.initialization();
		srchObj.intialize_PageClass();
		srchObj.launchApplication(applicationURL);
		testBaseObj.getScreenshot("Application");
	}
	@Test
	public void runTest() throws InterruptedException
	{
		int count = 0;
		count = srchObj.getCountOfSearchResults("Technology");
		System.out.println("No of Results displayed: "+count);
		List<String> allResultTitle = new ArrayList<String>();
		allResultTitle = srchObj.displaySearchResult();
		testBaseObj.getScreenshot("All Result");
		for(int i=0;i<allResultTitle.size();i++)
			System.out.println("ResultTitle: "+allResultTitle.get(i).toString());
		srchObj.openResult(3);
		testBaseObj.getScreenshot("Result");
	}
	
	@Test
	public void runTest2() throws InterruptedException
	{
		int count = 0;
		count = srchObj.getCountOfSearchResults("Hitachi");
		System.out.println("No of Results displayed: "+count);
		List<String> allResultTitle = new ArrayList<String>();
		allResultTitle = srchObj.displaySearchResult();
		testBaseObj.getScreenshot("All Result2");
		for(int i=0;i<allResultTitle.size();i++)
			System.out.println("ResultTitle: "+allResultTitle.get(i).toString());
		srchObj.openResult(0);
		testBaseObj.getScreenshot("Result2");
	}
	
	@AfterMethod
	public void endTest()
	{
		srchObj.closeApplication();
	}

}
