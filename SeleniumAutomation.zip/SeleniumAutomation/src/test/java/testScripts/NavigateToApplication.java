//Launch Application

package testScripts;

import org.testng.Assert;
import org.testng.annotations.Test;

import Base.TestBase;
import pages.Search;

public class NavigateToApplication {

	Search srchObj = new Search();
	TestBase testBaseObj = new TestBase();
	String searchKeyword = "Technology";
	String applicationURL = "https://global.hitachi-solutions.com";
	
	
	@Test
	public void runTest() throws InterruptedException
	{
		testBaseObj.initialization();
		srchObj.intialize_PageClass();
		srchObj.launchApplication(applicationURL);
		Assert.assertTrue(srchObj.verifyHitachiLogo());
		testBaseObj.getScreenshot("Application");
		srchObj.closeApplication();
	}
	
}
