package Base;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestBase {

	private Properties prop;
	private static WebDriver driver;
	JavascriptExecutor js;
	static WebDriverWait wait;

	public TestBase() {
		try {
			File file = new File("./src/main/java/config.properties");
			FileInputStream fileInput = new FileInputStream(file);
			prop = new Properties();
			prop.load(fileInput);
		} catch (IOException e) {

		}
	}

	public WebDriver getDriver() {
		return driver;
	}

	public void initialization() {
		if (prop.getProperty("Browser").equals("Chrome")) {
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
		} else if (prop.getProperty("Browser").equals("FireFox")) {
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
		} else
			System.out.println("No driver specified");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
		js = (JavascriptExecutor) driver;

	}
	
	public void clickByJavaExecutor(WebElement element) {
		js = (JavascriptExecutor)driver;
		wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.elementToBeClickable(element));
		js.executeScript("arguments[0].scrollIntoView();",element);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		js.executeScript("arguments[0].click();",element);
		System.out.println("Element:" + element.toString() + " clicked");
	}

	public void click(WebElement element) {
		js = (JavascriptExecutor)driver;
		try {
		wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.elementToBeClickable(element));
		js.executeScript("arguments[0].scrollIntoView();",element);
		element.click();
		System.out.println("Element:" + element.toString() + " clicked");
		}
		catch(ElementClickInterceptedException e)
		{
			js.executeScript("arguments[0].click();",element);
		}
	}

	public void launchURL(String url) {
		driver.get(url);
	}

	public boolean isElementEnabled(WebElement element) {
		boolean flag = false;
		try {
			if (isElementDisplayed(element))
				flag = element.isEnabled();
			else
				System.out.println("Element not displayed");
		} catch (ElementNotVisibleException e) {

		}
		return flag;
	}

	public boolean isElementDisplayed(WebElement element) {
		boolean flag = false;
		try {
			flag = element.isDisplayed();
		} catch (ElementNotVisibleException e) {

		}
		return flag;
	}

	public void setText(WebElement element, String text) {
		if (isElementEnabled(element))
			element.sendKeys(text);
	}

	public WebElement getElement(String locatorType, String locatorValue) {
		WebElement element = null;
		switch (locatorType) {
		case "id":
			element = driver.findElement(By.id(locatorValue));
		case "name":
			element = driver.findElement(By.name(locatorValue));
		case "xpath":
			element = driver.findElement(By.xpath(locatorValue));
		case "css":
			element = driver.findElement(By.cssSelector(locatorValue));
		}
		return element;
	}

	public List<WebElement> getListofElement(String locatorType, String locatorValue) {
		List<WebElement> element = null;
		switch (locatorType) {
		case "id":
			element = driver.findElements(By.id(locatorValue));
		case "name":
			element = driver.findElements(By.name(locatorValue));
		case "xpath":
			element = driver.findElements(By.xpath(locatorValue));
		case "css":
			element = driver.findElements(By.cssSelector(locatorValue));
		}
		return element;
	}

	public void closeBrowser() {
		driver.quit();
	}

	public void refreshBrowser() {
		driver.navigate().refresh();
	}

	public void getScreenshot(String fileName) {
		try {
			TakesScreenshot screenshot = (TakesScreenshot) driver;
			File srcFile = screenshot.getScreenshotAs(OutputType.FILE);
			File destFile = new File("./Screenshot/" + fileName + ".png");
			FileUtils.copyFile(srcFile, destFile);
		} catch (IOException f) {

		}
	}

	public String getTitle() {
		return driver.getTitle();
	}

	public String getWindowID() {
		return driver.getWindowHandle();
	}

	public Set<String> getAllWindows() {
		return driver.getWindowHandles();
	}

	public Alert switchTOAlert() {
		return driver.switchTo().alert();
	}

	public void switchToFrame(String switchType, Object value) {
		switch (switchType) {
		case "index":
			driver.switchTo().frame((int) value);
		case "name":
			driver.switchTo().frame((String) value);
		case "WebElement":
			driver.switchTo().frame((WebElement) value);
		}
	}

	public void switchTOWindow(String windowID) {
		driver.switchTo().window(windowID);
	}

	public String getCurrentDate() {
		DateFormat dt = new SimpleDateFormat("M/dd/yyyy");
		Date date = new Date();
		return dt.format(date);
	}
}
