package pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import Base.TestBase;

public class Search extends TestBase {

	TestBase testBase_obj = null;
	static WebDriver page_driver = null;
	Action action = null;

	@FindBy(id = "open-global-search")
	private WebElement lnk_GlobalSearch;

	@FindBy(id = "site-search-keyword")
	private WebElement txt_SrchTextBox;

	@FindBy(xpath = "//button[@aria-label='search']")
	private WebElement btnSrchSubmit;

	@FindAll(@FindBy(xpath = "//div[@class='search-result']"))
	private List<WebElement> searchResult;

	@FindAll(@FindBy(xpath = "//div[@class='search-result']/p"))
	private List<WebElement> searchResultTitle;

	@FindBy(xpath = "//nav[@id='primary-nav']/ul/li/a[@class='hitachi-solutions-logo']")
	private WebElement hitachiLOGO;

	@FindBy(xpath = "//div[@class='post-heading-meta']/h1")
	private WebElement openSearchResultTitle;

	public Search() {
		testBase_obj = new TestBase();
	}

	public void intialize_PageClass() {
		page_driver = testBase_obj.getDriver();
		PageFactory.initElements(page_driver, this);
	}

	public void launchApplication(String URL) {
		testBase_obj.launchURL(URL);
	}

	public void closeApplication() {
		testBase_obj.closeBrowser();
	}

	public int getCountOfSearchResults(String searchKeyword) throws InterruptedException {
		testBase_obj.click(lnk_GlobalSearch);
		testBase_obj.setText(txt_SrchTextBox, searchKeyword);
		testBase_obj.click(btnSrchSubmit);
		return searchResult.size();
	}

	public List<String> displaySearchResult() throws InterruptedException {
		List<String> descriptionOfResults = new ArrayList<String>();
		for (int i = 0; i < searchResultTitle.size(); i++) {
			descriptionOfResults.add(searchResultTitle.get(i).getText());

		}
		return descriptionOfResults;
	}

	public boolean verifyHitachiLogo() {
		return testBase_obj.isElementDisplayed(hitachiLOGO);
	}

	public void openResult(int index) {
		for (int i = 0; i < searchResultTitle.size(); i++) {
			if (i == index) {
				System.out.println("Result opened: " + searchResultTitle.get(index).getText());
				String expectedtext = searchResultTitle.get(index).getText();
				testBase_obj.clickByJavaExecutor(searchResultTitle.get(index));
				testBase_obj.click(searchResultTitle.get(index));
				WebElement newPageOpened = page_driver.findElement(By.xpath("//h1[text()='"+expectedtext+"']"));
				if (newPageOpened.isDisplayed()) {
					System.out.println("Correct result opened");
				} else {
					System.out.println("Some error in opening result");
					assert false;
				}
			}
		}
	}

}
